<!DOCTYPE html>
<html lang="es">

	<header>
		<div class="wrapp">
			<a href="#"><img src="head.png" alt="FalconMasters"></a>
		</div>
	</header>