<?php include('../header/header.php');?> 

 <section class="main">
		<div class="wrapp">
			<div class="mensaje">
				<h1>Bienvenido!</h1>
			</div>
 
			<div class="FORM">
                <label>RAZON SOCIAL:</label>
                <input id="NB_CLIENTE" type="text" class="form-control" required>
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
			<p>&nbsp;</p>
        </div>
	</section>
    <?php include('../footer/footer.php');?> 
	
</body>
</html>