<?php
   $host="localhost";
	$usuario1="briane19_briane1";
	$clave="Br1@n32019";
	$base="briane19_adminbriane";
	 $conexion=new mysqli($host,$usuario1,$clave,$base); 
     if ($conexion->connect_errno) 
     {
 	    die("fallo de la conexion");
 	 }

?>